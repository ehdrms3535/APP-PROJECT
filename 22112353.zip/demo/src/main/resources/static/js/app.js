// app.js
(function() {
  'use strict';

  // rideMapApp 모듈을 한 번 정의(definition) 합니다.
//  두 번째 인자([])가 있어야 정의가 됩니다.
  angular.module('rideMapApp', [
    // 여기에 ngRoute, ngAnimate 같은 의존 모듈이 필요하다면 추가
  ]);

})();