package com.example.demo.dto;
public class JoinRequest {
    private Long userId;
    public JoinRequest() {}
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
}